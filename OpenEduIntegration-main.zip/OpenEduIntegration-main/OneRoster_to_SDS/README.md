# Integration Solution: OneRoster to SDS
This solution demonstrates the use of Azure Data Factory to orchestrate the scheduled extraction of roster data via OneRoster API.
