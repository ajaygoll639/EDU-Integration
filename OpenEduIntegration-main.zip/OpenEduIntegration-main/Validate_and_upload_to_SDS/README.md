# Integration Solution: Validate and upload to SDS
This solution demonstrates the use of Azure Data Factory to orchestrate the scheduled validation and upload of SDS csv files to SDS profiles.

See [Solution Guide: Validate and Upload to SDS](https://github.com/microsoft/OpenEduIntegration/blob/main/Validate_and_upload_to_SDS/Validate_and_upload_to_SDS.pdf) for detailed documentation.

