This is sample data generated utilizing a python data generator script.
The names and dates and other fields are randomly generated and entirely fictional.

There are several errors intentionally included in this data to facilitate the testing of error conditions.
Errors in the data include:
- students with no SIS ID
- sections that do not have a teacher assigned in teacherroster.csv
- teachers with no Username
